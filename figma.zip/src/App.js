import React, { useState } from "react";
import Header from "./components/header";
import { MENU } from "./Data/Menu";
import "./style/index.sass";
import Login from "./components/login";

function App() {
  const [changeDir, setChangeDir] = useState("Home");

  function handleClick(index) {
    setChangeDir(index);
  }
  console.log(changeDir);
  return (
    <>
      {changeDir === "Login" ? (
        <Login />
      ) : (
        <Header
          menu={MENU}
          changeDirectionHandler={() => handleClick("Login")}
        />
      )}
    </>
  );
}

export default App;
