import React from "react";
import NavigationBar from "./navigation";
import TopSection from "./topSection";

const Header = (props) => {
  return (
    <header className="header">
      <NavigationBar menu={props.menu} changeDirectionHandler={props.changeDirectionHandler} />
      <TopSection />
    </header>
  );
};

export default Header;
