import React from "react";
import Menu from "../menu";
import "../../../style/font/font-awesome-4.7.0/css/font-awesome.css";

const NavigationBar = (props) => {
  return (
    <>
      <nav className="header__nav">
        <img src="/assets/image/logo.svg" alt="Logo" />
        <Menu menu={props.menu} />
        {localStorage.getItem("token") || sessionStorage.getItem("token") ? (
          <button
            style={props.loginPage ? { display: "none" } : null}
            className="header__nav__button"
            onClick={props.changeDirectionHandler}
          >
            Panel
          </button>
        ) : (
          <button
            style={props.loginPage ? { display: "none" } : null}
            className="header__nav__button"
            onClick={props.changeDirectionHandler}
          >
            Login
          </button>
        )}
        <i className="fa fa-bars fa-2x header__nav__i"></i>
      </nav>
    </>
  );
};
export default NavigationBar;
