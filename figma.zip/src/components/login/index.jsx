import React from "react";
import LoginPage from "./loginPage";

const Login = () => {
  return <LoginPage />;
};

export default Login;
