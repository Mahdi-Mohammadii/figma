import React from "react";

const card = (props) => {
    return(
        <>
            
        </>
    )
}