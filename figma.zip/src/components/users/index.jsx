import React, { useEffect, useState } from "react";
import axios from "axios";
import NavigationBar from "../header/navigation";

const Users = () => {
  const [users, setUsers] = useState();
  useEffect(() => {
    axios
      .get("https://api.github.com/users")
      .then((resp) => setUsers(resp.data));
  }, []);
  if (!users) return null;
  return (
    <>
      <header className="header">
        <NavigationBar loginPage={true} />
      </header>
      <ul>
        {users.map((item) => {
          return (
            <li key={item.login} style={{ color: "#000" }}>
              {item.login}
            </li>
          );
        })}
      </ul>
    </>
  );
};

export default Users;
