export const MENU = [
  {
    name: "HOME",
    link: "/home",
    id: "home",
  },
  {
    name: "POPULAR",
    link: "/popular",
    id: "popular",
  },
  {
    name: "NEW COMER",
    link: "/newcomer",
    id: "newcomer",
  },
  {
    name: "ABOUT",
    link: "/abou",
    id: "about",
  },
];
